from transformers import pipeline
import re

class SecurityFilter:
    def __init__(self):
        self.classifier = pipeline("text-classification", model="bert-base-multilingual-cased")
        self.sensitive_patterns = {
            "ar": [r"عنف", r"سياسة", r"حرب"],
            "en": [r"violence", r"politics", r"war"]
        }
    
    def analyze_query(self, query: str, lang: str) -> tuple[bool, str]:
        normalized = normalize_text(query)
        for pattern in self.sensitive_patterns.get(lang, []):
            if re.search(pattern, normalized, re.IGNORECASE):
                return False, "Sensitive content detected"
        score = self.classifier(normalized)[0]["score"]
        return (True, "") if score < 0.9 else (False, "High-risk query")

    def analyze_results(self, results: list, lang: str) -> tuple[bool, str]:
        for doc in results:
            content = normalize_text(doc.get("content", ""))
            for pattern in self.sensitive_patterns.get(lang, []):
                if re.search(pattern, content, re.IGNORECASE):
                    return False, "Unrelated sensitive content"
        return True, ""

security = SecurityFilter()
is_safe, reason = security.analyze_query("Violent crime laws", "en")