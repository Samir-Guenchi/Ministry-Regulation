import faiss
import numpy as np

def create_faiss_index(embeddings: np.ndarray, dimension=768):
    nlist = 1000  
    m = 96  
    quantizer = faiss.IndexFlatIP(dimension)
    index = faiss.IndexIVFPQ(quantizer, dimension, nlist, m, 8)
    index.train(embeddings)
    index.add(embeddings)
    return index

embeddings = np.random.random((5000000, 768)).astype('float32')
faiss_index = create_faiss_index(embeddings)