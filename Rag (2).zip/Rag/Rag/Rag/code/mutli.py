import concurrent.futures
import time
import requests
from flask import current_app as app
from typing import Dict, List, Optional

class YearSearchWorker:
    def __init__(self, base_url: str, timeout: int = 10):
        self.base_url = base_url
        self.timeout = timeout
    
    def search(self, year: int, query: str, filters: Optional[Dict] = None) -> Dict:
        url = f"{self.base_url}/{year}"
        payload = {"query": query, "filters": filters or {}}
        try:
            start_time = time.time()
            response = requests.post(url, json=payload, timeout=self.timeout)
            response.raise_for_status()
            result = response.json()
            result.update({"year": year, "response_time_ms": int((time.time() - start_time) * 1000)})
            return result
        except requests.RequestException as e:
            app.logger.error(f"Year {year} search failed: {str(e)}")
            return {"year": year, "error": str(e), "results": []}

class MultiThreadedSearchOrchestrator:
    def __init__(self, base_url: str, years: List[int], max_workers: int = None):
        self.worker = YearSearchWorker(base_url)
        self.years = years
        self.max_workers = max_workers or len(years)
    
    def execute_search(self, query: str, filters: Optional[Dict] = None) -> Dict:
        start_time = time.time()
        results = []
        errors = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_year = {executor.submit(self.worker.search, year, query, filters): year for year in self.years}
            for future in concurrent.futures.as_completed(future_to_year):
                try:
                    result = future.result()
                    (errors if "error" in result else results).append(result)
                except Exception as exc:
                    year = future_to_year[future]
                    errors.append({"year": year, "error": str(exc), "results": []})
        all_documents = [doc for r in results if "results" in r for doc in r["results"]]
        all_documents.sort(key=lambda x: x.get("relevance_score", 0), reverse=True)
        return {
            "query": query,
            "results": all_documents,
            "total_found": len(all_documents),
            "errors": errors if errors else None,
            "processing_time_ms": int((time.time() - start_time) * 1000)
        }

orchestrator = MultiThreadedSearchOrchestrator("http://internal-api.laws/search", range(2018, 2025))
results = orchestrator.execute_search("taxation laws", {"ministries": ["Finance"]})