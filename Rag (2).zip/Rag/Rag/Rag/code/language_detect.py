from langdetect import detect, LangDetectException
from typing import Dict, Any

class LanguageProcessor:
    def __init__(self):
        self.field_translations = {
            "query": "الاستعلام",
            "results": "النتائج",
            "total_found": "إجمالي النتائج",
            "relevance_score": "درجة الصلة",
            "title": "العنوان",
            "ministry": "الوزارة",
            "year": "السنة"
        }
    
    def detect_language(self, text: str) -> str:
        try:
            if re.search(r'[\u0600-\u06FF]', text):
                return "ar"
            lang = detect(text)
            return lang if lang in ["ar", "en"] else "en"
        except LangDetectException:
            return "en"
    
    def format_response(self, results: Dict[str, Any], lang: str) -> Dict[str, Any]:
        if lang == "ar":
            translated = {}
            for k, v in results.items():
                new_key = self.field_translations.get(k, k)
                translated[new_key] = self.format_response(v, lang) if isinstance(v, dict) else v
            return translated
        return results

processor = LanguageProcessor()
