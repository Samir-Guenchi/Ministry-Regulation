import re
from pyarabic.araby import strip_tashkeel, normalize_hamza

def normalize_text(text: str) -> str:
    text = strip_tashkeel(text)
    text = normalize_hamza(text, method="tasheel")
    text = re.sub(r'ى', 'ي', text)
    text = re.sub(r'ة', 'ه', text)
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'[^\w\s]', '', text)
    return text.strip().lower()